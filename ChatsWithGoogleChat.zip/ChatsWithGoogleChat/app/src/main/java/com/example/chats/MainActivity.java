package com.example.chats;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * אפליקציית צאטים עם לשוניות. כל לשונית היא WebView נפרד שנשמר בזיכרון,
 * כך שמעבר בין לשוניות לא מאבד את מצב השיחה.
 *
 * להוספת אתר נוסף: הוסף שורה ב-TITLES ושורה מתאימה ב-URLS (באותו סדר).
 */
public class MainActivity extends Activity {

    private static final String[] TITLES = {"Black Cat", "AliExpress", "Google Chat"};
    private static final String[] URLS = {
            "https://black-cat.thechats.click/",
            "https://aliexpress.thechats.click/",
            "https://chat.google.com/"
    };
    // לשוניות שנטענות עם זהות דפדפן Chrome (נדרש ל-Google Chat)
    private static final boolean[] CHROME_UA = {false, false, true};

    private static final int FILE_REQ = 1001;

    private final WebView[] views = new WebView[TITLES.length];
    private final Button[] tabButtons = new Button[TITLES.length];
    private FrameLayout content;
    private int current = -1;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#EEEEEE"));
        bar.setGravity(Gravity.CENTER_VERTICAL);

        for (int i = 0; i < TITLES.length; i++) {
            final int index = i;
            Button b = new Button(this);
            b.setText(TITLES[i]);
            b.setAllCaps(false);
            b.setSingleLine(true);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    select(index);
                }
            });
            bar.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabButtons[i] = b;
        }

        Button external = new Button(this);
        external.setText("↗");
        external.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openExternal();
            }
        });
        bar.addView(external, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content = new FrameLayout(this);

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        select(0);
    }

    private void select(int index) {
        if (views[index] == null) {
            views[index] = createWebView(index);
            content.addView(views[index], new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            views[index].loadUrl(URLS[index]);
        }
        for (int i = 0; i < views.length; i++) {
            if (views[i] != null) {
                views[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            }
            tabButtons[i].setBackgroundColor(i == index
                    ? Color.parseColor("#BBDEFB") : Color.TRANSPARENT);
        }
        current = index;
    }

    private WebView createWebView(int index) {
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        if (CHROME_UA[index]) {
            // Google חוסמת התחברות מתוך WebView רגיל; זהות Chrome מקטינה את הסיכוי לחסימה.
            String ua = s.getUserAgentString()
                    .replace("; wv", "")
                    .replace("Version/4.0 ", "");
            s.setUserAgentString(ua);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false; // נשאר בתוך האפליקציה
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "אין אפליקציה שיכולה לפתוח את הקישור",
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        return wv;
    }

    /** פותח את הלשונית הנוכחית בדפדפן / באפליקציית Google Chat אם מותקנת. */
    private void openExternal() {
        if (current < 0) return;
        WebView wv = views[current];
        String url = (wv != null && wv.getUrl() != null) ? wv.getUrl() : URLS[current];
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "לא נמצא דפדפן", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (current >= 0 && views[current] != null && views[current].canGoBack()) {
            views[current].goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        for (WebView wv : views) {
            if (wv != null) {
                content.removeView(wv);
                wv.destroy();
            }
        }
        super.onDestroy();
    }
}

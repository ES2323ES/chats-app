package com.example.chats;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * צ׳אטים: אפליקציה עם לשוניות שאפשר לנהל מתוך האפליקציה.
 * לשונית רגילה = WebView שנשמר בזיכרון, עם מסך שגיאה בעברית.
 * לשונית Google Chat = מסך שמפעיל את האפליקציה הרשמית של Google,
 * כי Google לא מאפשרת התחברות בתוך WebView של אפליקציות צד שלישי.
 */
public class MainActivity extends Activity {

    private static final String GOOGLE_CHAT_PACKAGE = "com.google.android.apps.dynamite";
    private static final String GOOGLE_CHAT_URL = "https://chat.google.com/";

    private static final int TYPE_WEB = 0;       // אתר רגיל בתוך האפליקציה
    private static final int TYPE_GCHAT = 1;     // מסך הפעלה של Google Chat
    private static final int TYPE_EXTERNAL = 2;  // נפתח בדפדפן (אתרי Google אחרים)

    private static final int MAX_TABS = 12;
    private static final int FILE_REQ = 1001;
    private static final int AUTH_REQ = 1002;
    private static final int PERM_REQ = 1003;
    private static final int TEXT_ZOOM_MIN = 70;
    private static final int TEXT_ZOOM_MAX = 200;
    private static final long LOCK_DELAY_MS = 60000L;

    // סימונים: שורה שמתחילה ב-"# " = כותרת, **טקסט** = מונח מודגש בצבע, !!טקסט!! = הערה חשובה באדום
    private static final String GUIDE_TEXT =
            "# הלשוניות\n"
            + "בראש המסך יש לשוניות. לחיצה על לשונית עוברת אליה, והאתר נשמר במצבו כשחוזרים אליו. "
            + "האפליקציה נפתחת בלשונית שבה סגרת אותה. כשיש הרבה לשוניות, אפשר להחליק את השורה הצידה.\n\n"
            + "# ניהול אתרים\n"
            + "תפריט **⋮** ← **נהל אתרים**. אפשר להוסיף אתר (שם וכתובת), לערוך, למחוק ולשנות סדר בעזרת **▲ ▼**. "
            + "כתובת שמתחילה ב-http מומרת אוטומטית ל-https. חייבת להישאר לפחות לשונית אחת.\n"
            + "!!אתרי Google!! (חוץ מ-Google Chat) נפתחים בדפדפן, כי Google חוסמת התחברות בתוך אפליקציות כמו זו.\n\n"
            + "# כפתור ↻\n"
            + "**↻** מרענן את הדף הנוכחי. פס דק מתחת לשורה מראה את התקדמות הטעינה.\n\n"
            + "# תפריט ⋮\n"
            + "• **רענן**: טוען מחדש את הדף.\n"
            + "• **שתף קישור / העתק קישור**: של הדף הנוכחי.\n"
            + "• **פתח בדפדפן**: פותח את הדף הנוכחי בכרום או בדפדפן אחר.\n"
            + "• **הגדל / הקטן / אפס גודל טקסט**: משנה את גודל הכתב באתר הנוכחי בלבד, והגודל נשמר לכל אתר בנפרד.\n"
            + "• **הכהיית אתרים**: מכהה אתרים אוטומטית כשהטלפון במצב כהה. אם אתר נראה רע, אפשר לכבות.\n"
            + "• **התנתק ונקה נתונים**: מוחק עוגיות ומטמון של כל האתרים, !!ותצטרך להתחבר מחדש!!.\n\n"
            + "# מצלמה ומיקרופון\n"
            + "אתר שמבקש מצלמה או מיקרופון (למשל להקלטת הודעה קולית) יגרום להצגת בקשת הרשאה של "
            + "אנדרואיד בפעם הראשונה. אפשר לבטל בכל עת בהגדרות הטלפון ← אפליקציות ← צ׳אטים ← הרשאות.\n\n"
            + "# נעילה\n"
            + "תפריט **⋮** ← **הפעל נעילה**. האפליקציה תבקש לאמת זהות באמצעות נעילת המסך של הטלפון "
            + "בכל פתיחה, ואחרי שהייתה ברקע יותר מדקה. !!הדבר דורש נעילת מסך שמוגדרת בטלפון.!! "
            + "הנעילה חלה על האפליקציה הזו בלבד, ולא על Google Chat.\n\n"
            + "# חסימת צילומי מסך\n"
            + "תפריט **⋮** ← **חסום צילומי מסך**. מונע צילום מסך והקלטה מתוך האפליקציה, "
            + "ומסתיר את התוכן ברשימת האפליקציות האחרונות.\n\n"
            + "# גוגל צ'אט\n"
            + "הלשונית פותחת את אפליקציית **Google Chat** הרשמית. אם היא לא מותקנת, תיפתח החנות.\n\n"
            + "# הורדת קבצים\n"
            + "קבצים שהאתר מציע להורדה נשמרים בתיקיית ההורדות של הטלפון. "
            + "!!הורדות מסוימות שנוצרות בתוך הדף עצמו אינן נתמכות.!!\n\n"
            + "# שגיאות\n"
            + "אם אין חיבור או שהאתר לא זמין, יוצג מסך עם כפתור **נסה שוב**.\n\n"
            + "# יציאה\n"
            + "לחיצה על **חזור** חוזרת אחורה בדף. כשאי אפשר לחזור, צריך ללחוץ פעמיים כדי לצאת מהאפליקציה.";

    /** לשונית אחת: הגדרות (שם, כתובת, סוג) ומצב תצוגה. */
    private static class Tab {
        String name;
        String url;
        int type;
        FrameLayout holder;
        WebView web;
        View errorView;
        boolean hadError;
        Button button;

        Tab(String name, String url, int type) {
            this.name = name;
            this.url = url;
            this.type = type;
        }
    }

    private final ArrayList<Tab> tabs = new ArrayList<Tab>();

    private LinearLayout tabsRow;
    private FrameLayout content;
    private ProgressBar progress;
    private View guideView;
    private View manageView;
    private LinearLayout manageList;
    private View lockView;

    private SharedPreferences prefs;
    private boolean night;
    private boolean webDark;
    private boolean lockEnabled;
    private boolean secure;
    private boolean locked;
    private boolean authInProgress;
    private boolean authDeclined;
    private int current = -1;
    private long lastBackTime = 0;
    private long backgroundTime = 0;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingPermission;

    // ---------------------------------------------------------------- creation

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("chats", MODE_PRIVATE);
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        webDark = prefs.getBoolean("web_dark", true);
        lockEnabled = prefs.getBoolean("lock_enabled", false);
        secure = prefs.getBoolean("secure", false);
        applySecure();
        loadSites();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor(night ? "#2B2B2B" : "#EEEEEE"));
        bar.setGravity(Gravity.CENTER_VERTICAL);

        HorizontalScrollView tabsScroll = new HorizontalScrollView(this);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsScroll.addView(tabsRow);
        bar.addView(tabsScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button refresh = newBarButton("↻");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshCurrent();
            }
        });
        bar.addView(refresh, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button menu = newBarButton("⋮");
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu(v);
            }
        });
        bar.addView(menu, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.INVISIBLE);

        content = new FrameLayout(this);
        guideView = createGuideView();
        manageView = createManageView();
        content.addView(guideView, matchFrame());
        content.addView(manageView, matchFrame());

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(progress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        FrameLayout outer = new FrameLayout(this);
        outer.addView(root, matchFrame());
        lockView = createLockView();
        outer.addView(lockView, matchFrame());
        setContentView(outer);

        rebuildBar();
        setLocked(lockEnabled);

        int last = prefs.getInt("last_tab", 0);
        if (last < 0 || last >= tabs.size()) {
            last = 0;
        }
        select(last);
    }

    private FrameLayout.LayoutParams matchFrame() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private Button newBarButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private int surfaceColor() {
        return night ? Color.parseColor("#121212") : Color.WHITE;
    }

    // ---------------------------------------------------------------- sites storage

    private void loadSites() {
        tabs.clear();
        String json = prefs.getString("sites", null);
        if (json != null) {
            try {
                JSONArray arr = new JSONArray(json);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    tabs.add(new Tab(o.getString("name"), o.getString("url"),
                            o.optInt("type", TYPE_WEB)));
                }
            } catch (JSONException e) {
                tabs.clear();
            }
        }
        if (tabs.isEmpty()) {
            tabs.add(new Tab("החתול השחור", "https://black-cat.thechats.click/", TYPE_WEB));
            tabs.add(new Tab("הפרגוד", "https://www.hapargod.co.il/post", TYPE_WEB));
            tabs.add(new Tab("גוגל צ'אט", GOOGLE_CHAT_URL, TYPE_GCHAT));
        }
    }

    private void saveSites() {
        JSONArray arr = new JSONArray();
        try {
            for (Tab t : tabs) {
                JSONObject o = new JSONObject();
                o.put("name", t.name);
                o.put("url", t.url);
                o.put("type", t.type);
                arr.put(o);
            }
            prefs.edit().putString("sites", arr.toString()).apply();
        } catch (JSONException e) {
            Toast.makeText(this, "שמירת רשימת האתרים נכשלה", Toast.LENGTH_SHORT).show();
        }
    }

    private String normalizeUrl(String input) {
        String u = (input == null) ? "" : input.trim();
        if (u.length() == 0) {
            return null;
        }
        if (u.startsWith("http://")) {
            u = "https://" + u.substring(7);
        } else if (!u.startsWith("https://")) {
            u = "https://" + u;
        }
        String host = Uri.parse(u).getHost();
        if (host == null || host.length() == 0 || !host.contains(".")) {
            return null;
        }
        return u;
    }

    private int typeForUrl(String url) {
        String host = Uri.parse(url).getHost();
        if (host == null) {
            return TYPE_WEB;
        }
        host = host.toLowerCase();
        if (host.equals("chat.google.com")) {
            return TYPE_GCHAT;
        }
        if (host.equals("google.com") || host.endsWith(".google.com")) {
            return TYPE_EXTERNAL;
        }
        return TYPE_WEB;
    }

    // ---------------------------------------------------------------- tabs

    private Tab currentTab() {
        return (current >= 0 && current < tabs.size()) ? tabs.get(current) : null;
    }

    private WebView currentWeb() {
        Tab t = currentTab();
        return (t == null) ? null : t.web;
    }

    private void rebuildBar() {
        tabsRow.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final Tab t = tabs.get(i);
            Button b = newBarButton(t.name);
            b.setSingleLine(true);
            b.setTextSize(13);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    select(tabs.indexOf(t));
                }
            });
            tabsRow.addView(b, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            t.button = b;
        }
        updateTabColors();
    }

    private void updateTabColors() {
        for (int i = 0; i < tabs.size(); i++) {
            Button b = tabs.get(i).button;
            if (b != null) {
                b.setBackgroundColor(i == current
                        ? Color.parseColor(night ? "#37474F" : "#BBDEFB")
                        : Color.TRANSPARENT);
            }
        }
    }

    private void select(int index) {
        if (index < 0 || index >= tabs.size()) {
            return;
        }
        Tab sel = tabs.get(index);
        if (sel.holder == null) {
            createTab(sel);
        }
        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            if (t.holder != null) {
                t.holder.setVisibility(i == index ? View.VISIBLE : View.GONE);
            }
        }
        current = index;
        updateTabColors();
        prefs.edit().putInt("last_tab", index).apply();
        updateProgress();
    }

    private void createTab(Tab t) {
        FrameLayout holder = new FrameLayout(this);
        if (t.type == TYPE_GCHAT) {
            holder.addView(createGoogleChatPanel(t), matchFrame());
        } else if (t.type == TYPE_EXTERNAL) {
            holder.addView(createExternalPanel(t), matchFrame());
        } else {
            WebView wv = createWebView(t);
            t.web = wv;
            holder.addView(wv, matchFrame());

            View err = createErrorView(t);
            err.setVisibility(View.GONE);
            t.errorView = err;
            holder.addView(err, matchFrame());

            wv.loadUrl(t.url);
        }
        t.holder = holder;
        content.addView(holder, matchFrame());
    }

    private void destroyTab(Tab t) {
        if (t.web != null) {
            if (t.holder != null) {
                t.holder.removeView(t.web);
            }
            t.web.destroy();
            t.web = null;
        }
        if (t.holder != null) {
            content.removeView(t.holder);
            t.holder = null;
        }
        t.errorView = null;
    }

    private void updateProgress() {
        WebView w = currentWeb();
        if (w != null && w.getProgress() < 100) {
            progress.setProgress(w.getProgress());
            progress.setVisibility(View.VISIBLE);
        } else {
            progress.setVisibility(View.INVISIBLE);
        }
    }

    // ---------------------------------------------------------------- panels

    private View createGoogleChatPanel(Tab t) {
        int pad = dp(24);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(t.name);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("Google אינה מאפשרת התחברות בתוך אפליקציות כמו זו, מטעמי אבטחה. "
                + "לכן הצ'אט נפתח באפליקציה הרשמית של Google Chat.");
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, pad, 0, pad);

        Button openApp = new Button(this);
        openApp.setText("פתח באפליקציית Google Chat");
        openApp.setAllCaps(false);
        openApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGoogleChatApp();
            }
        });

        panel.addView(title);
        panel.addView(info);
        panel.addView(openApp);
        return panel;
    }

    private View createExternalPanel(final Tab t) {
        int pad = dp(24);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(t.name);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("האתר הזה נפתח בדפדפן, כי Google חוסמת התחברות בתוך אפליקציות כמו זו.");
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, pad, 0, pad);

        Button open = new Button(this);
        open.setText("פתח בדפדפן");
        open.setAllCaps(false);
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl(t.url);
            }
        });

        panel.addView(title);
        panel.addView(info);
        panel.addView(open);
        return panel;
    }

    private View createErrorView(final Tab t) {
        int pad = dp(24);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(pad, pad, pad, pad);
        box.setBackgroundColor(surfaceColor());
        box.setClickable(true); // חוסם לחיצות על ה-WebView שמתחת

        TextView msg = new TextView(this);
        msg.setText("אין חיבור לאינטרנט, או שהאתר לא זמין כרגע.");
        msg.setTextSize(18);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 0, 0, pad);

        Button retry = new Button(this);
        retry.setText("נסה שוב");
        retry.setAllCaps(false);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (t.web != null) {
                    t.web.loadUrl(t.url);
                }
            }
        });

        box.addView(msg);
        box.addView(retry);
        return box;
    }

    private View createGuideView() {
        int pad = dp(20);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(surfaceColor());
        scroll.setClickable(true);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("מדריך למשתמש");
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.parseColor(night ? "#90CAF9" : "#1565C0"));
        title.setPadding(0, 0, 0, pad);

        TextView body = new TextView(this);
        body.setText(buildGuide());
        body.setTextSize(16);
        body.setLineSpacing(0f, 1.2f);

        Button close = new Button(this);
        close.setText("סגור");
        close.setAllCaps(false);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guideView.setVisibility(View.GONE);
            }
        });

        box.addView(title);
        box.addView(body);
        box.addView(close);
        scroll.addView(box);
        scroll.setVisibility(View.GONE);
        return scroll;
    }

    private void showGuide() {
        guideView.setVisibility(View.VISIBLE);
        guideView.bringToFront();
    }

    private View createLockView() {
        int pad = dp(24);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(pad, pad, pad, pad);
        box.setBackgroundColor(surfaceColor());
        box.setClickable(true);

        TextView msg = new TextView(this);
        msg.setText("האפליקציה נעולה");
        msg.setTextSize(22);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 0, 0, pad);

        Button unlock = new Button(this);
        unlock.setText("פתח נעילה");
        unlock.setAllCaps(false);
        unlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                authDeclined = false;
                startAuth();
            }
        });

        box.addView(msg);
        box.addView(unlock);
        box.setVisibility(View.GONE);
        return box;
    }

    // ---------------------------------------------------------------- guide formatting

    private CharSequence buildGuide() {
        int headColor = Color.parseColor(night ? "#90CAF9" : "#1565C0");
        int keyColor = Color.parseColor(night ? "#80CBC4" : "#00796B");
        int warnColor = Color.parseColor(night ? "#EF9A9A" : "#C62828");

        SpannableStringBuilder out = new SpannableStringBuilder();
        String[] lines = GUIDE_TEXT.split("\n", -1);
        for (int li = 0; li < lines.length; li++) {
            String line = lines[li];
            if (line.startsWith("# ")) {
                appendStyled(out, line.substring(2), headColor, 1.25f);
            } else {
                appendInline(out, line, keyColor, warnColor);
            }
            if (li < lines.length - 1) {
                out.append("\n");
            }
        }
        return out;
    }

    private void appendStyled(SpannableStringBuilder out, String text, int color, float size) {
        int start = out.length();
        out.append(text);
        int end = out.length();
        out.setSpan(new StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        out.setSpan(new ForegroundColorSpan(color), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (size != 1f) {
            out.setSpan(new RelativeSizeSpan(size), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    /** מעבד בתוך שורה את הסימונים **מונח** (מודגש בצבע) ו-!!הערה!! (מודגש באדום). */
    private void appendInline(SpannableStringBuilder out, String line, int keyColor, int warnColor) {
        int i = 0;
        while (i < line.length()) {
            int bold = line.indexOf("**", i);
            int warn = line.indexOf("!!", i);
            if (bold < 0 && warn < 0) {
                out.append(line.substring(i));
                return;
            }
            int next;
            String marker;
            if (warn < 0 || (bold >= 0 && bold < warn)) {
                next = bold;
                marker = "**";
            } else {
                next = warn;
                marker = "!!";
            }
            int close = line.indexOf(marker, next + 2);
            if (close < 0) {
                out.append(line.substring(i));
                return;
            }
            out.append(line.substring(i, next));
            appendStyled(out, line.substring(next + 2, close),
                    marker.equals("**") ? keyColor : warnColor, 1f);
            i = close + 2;
        }
    }

    // ---------------------------------------------------------------- manage sites

    private View createManageView() {
        int pad = dp(20);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(surfaceColor());
        scroll.setClickable(true);

        manageList = new LinearLayout(this);
        manageList.setOrientation(LinearLayout.VERTICAL);
        manageList.setPadding(pad, pad, pad, pad);
        scroll.addView(manageList);
        scroll.setVisibility(View.GONE);
        return scroll;
    }

    private void showManage() {
        refreshManageView();
        manageView.setVisibility(View.VISIBLE);
        manageView.bringToFront();
    }

    private Button rowButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(listener);
        return b;
    }

    private void refreshManageView() {
        int pad = dp(20);
        manageList.removeAllViews();

        TextView title = new TextView(this);
        title.setText("ניהול אתרים");
        title.setTextSize(22);
        title.setPadding(0, 0, 0, pad);
        manageList.addView(title);

        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView name = new TextView(this);
            name.setText(tabs.get(i).name);
            name.setTextSize(17);
            row.addView(name, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            row.addView(rowButton("▲", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    moveTab(index, -1);
                }
            }));
            row.addView(rowButton("▼", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    moveTab(index, 1);
                }
            }));
            row.addView(rowButton("✎", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSiteDialog(index);
                }
            }));
            row.addView(rowButton("✕", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmDeleteTab(index);
                }
            }));
            manageList.addView(row);
        }

        Button add = new Button(this);
        add.setText("הוסף אתר");
        add.setAllCaps(false);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSiteDialog(-1);
            }
        });

        Button close = new Button(this);
        close.setText("סגור");
        close.setAllCaps(false);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                manageView.setVisibility(View.GONE);
            }
        });

        manageList.addView(add);
        manageList.addView(close);
    }

    private void showSiteDialog(final int index) {
        final boolean edit = index >= 0;
        int pad = dp(20);

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(pad, pad, pad, 0);

        final EditText nameField = new EditText(this);
        nameField.setHint("שם הלשונית");
        nameField.setSingleLine(true);

        final EditText urlField = new EditText(this);
        urlField.setHint("כתובת האתר, למשל example.com");
        urlField.setSingleLine(true);
        urlField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);

        if (edit) {
            nameField.setText(tabs.get(index).name);
            urlField.setText(tabs.get(index).url);
        }
        form.addView(nameField);
        form.addView(urlField);

        new AlertDialog.Builder(this)
                .setTitle(edit ? "עריכת אתר" : "הוספת אתר")
                .setView(form)
                .setPositiveButton("שמור", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        saveSite(index, nameField.getText().toString(),
                                urlField.getText().toString());
                    }
                })
                .setNegativeButton("ביטול", null)
                .show();
    }

    private void saveSite(int index, String name, String rawUrl) {
        String url = normalizeUrl(rawUrl);
        if (url == null) {
            Toast.makeText(this, "כתובת האתר לא תקינה", Toast.LENGTH_LONG).show();
            return;
        }
        String n = (name == null) ? "" : name.trim();
        if (n.length() == 0) {
            n = Uri.parse(url).getHost();
        }
        int type = typeForUrl(url);

        if (index < 0) {
            if (tabs.size() >= MAX_TABS) {
                Toast.makeText(this, "אפשר להוסיף עד " + MAX_TABS + " לשוניות",
                        Toast.LENGTH_LONG).show();
                return;
            }
            tabs.add(new Tab(n, url, type));
            if (type == TYPE_EXTERNAL) {
                Toast.makeText(this, "אתרי Google נפתחים בדפדפן", Toast.LENGTH_LONG).show();
            }
            rebuildBar();
        } else {
            Tab old = tabs.get(index);
            if (old.url.equals(url) && old.type == type) {
                old.name = n;
                rebuildBar();
            } else {
                boolean wasCurrent = (current == index);
                destroyTab(old);
                tabs.set(index, new Tab(n, url, type));
                rebuildBar();
                if (wasCurrent) {
                    select(index);
                }
            }
        }
        saveSites();
        refreshManageView();
    }

    private void confirmDeleteTab(final int index) {
        new AlertDialog.Builder(this)
                .setTitle("מחיקת אתר")
                .setMessage("למחוק את " + tabs.get(index).name + "?")
                .setPositiveButton("מחק", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteTab(index);
                    }
                })
                .setNegativeButton("ביטול", null)
                .show();
    }

    private void deleteTab(int index) {
        if (tabs.size() <= 1) {
            Toast.makeText(this, "חייבת להישאר לפחות לשונית אחת", Toast.LENGTH_SHORT).show();
            return;
        }
        Tab t = tabs.remove(index);
        destroyTab(t);
        int previous = current;
        if (previous == index) {
            current = -1;
        } else if (previous > index) {
            current = previous - 1;
        }
        saveSites();
        rebuildBar();
        if (previous == index) {
            select(Math.min(index, tabs.size() - 1));
        }
        refreshManageView();
    }

    private void moveTab(int index, int delta) {
        int other = index + delta;
        if (other < 0 || other >= tabs.size()) {
            return;
        }
        Collections.swap(tabs, index, other);
        if (current == index) {
            current = other;
        } else if (current == other) {
            current = index;
        }
        prefs.edit().putInt("last_tab", current).apply();
        saveSites();
        rebuildBar();
        refreshManageView();
    }

    // ---------------------------------------------------------------- menu

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        boolean web = currentWeb() != null;
        if (web) {
            m.add(0, 1, 0, "רענן");
            m.add(0, 2, 0, "שתף קישור");
            m.add(0, 3, 0, "העתק קישור");
            m.add(0, 4, 0, "פתח בדפדפן");
            m.add(0, 5, 0, "הגדל טקסט");
            m.add(0, 6, 0, "הקטן טקסט");
            m.add(0, 7, 0, "אפס גודל טקסט");
        }
        m.add(0, 11, 0, "נהל אתרים");
        m.add(0, 8, 0, webDark ? "כבה הכהיית אתרים" : "הפעל הכהיית אתרים");
        m.add(0, 12, 0, lockEnabled ? "כבה נעילה" : "הפעל נעילה");
        m.add(0, 13, 0, secure ? "אפשר צילומי מסך" : "חסום צילומי מסך");
        m.add(0, 9, 0, "התנתק ונקה נתונים");
        m.add(0, 10, 0, "מדריך");

        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case 1:
                        refreshCurrent();
                        break;
                    case 2:
                        shareCurrentUrl();
                        break;
                    case 3:
                        copyCurrentUrl();
                        break;
                    case 4:
                        openUrl(currentUrl());
                        break;
                    case 5:
                        setTextZoom(currentZoom() + 10);
                        break;
                    case 6:
                        setTextZoom(currentZoom() - 10);
                        break;
                    case 7:
                        setTextZoom(100);
                        break;
                    case 8:
                        toggleWebDark();
                        break;
                    case 9:
                        confirmClearData();
                        break;
                    case 10:
                        showGuide();
                        break;
                    case 11:
                        showManage();
                        break;
                    case 12:
                        toggleLock();
                        break;
                    case 13:
                        toggleSecure();
                        break;
                    default:
                        break;
                }
                return true;
            }
        });
        pm.show();
    }

    private String currentUrl() {
        Tab t = currentTab();
        if (t == null) {
            return "";
        }
        if (t.web != null && t.web.getUrl() != null) {
            return t.web.getUrl();
        }
        return t.url;
    }

    private void refreshCurrent() {
        WebView w = currentWeb();
        if (w != null) {
            w.reload();
        } else {
            Toast.makeText(this, "אין מה לרענן בלשונית הזו", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareCurrentUrl() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, currentUrl());
        startActivity(Intent.createChooser(send, "שתף קישור"));
    }

    private void copyCurrentUrl() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("link", currentUrl()));
            Toast.makeText(this, "הקישור הועתק", Toast.LENGTH_SHORT).show();
        }
    }

    private String zoomKey(Tab t) {
        String host = Uri.parse(t.url).getHost();
        return "zoom_" + (host == null ? t.url : host);
    }

    private int currentZoom() {
        WebView w = currentWeb();
        return (w != null) ? w.getSettings().getTextZoom() : 100;
    }

    /** גודל הטקסט נשמר לכל אתר בנפרד ומשפיע רק על הלשונית הנוכחית. */
    private void setTextZoom(int value) {
        Tab t = currentTab();
        if (t == null || t.web == null) {
            return;
        }
        if (value < TEXT_ZOOM_MIN) {
            value = TEXT_ZOOM_MIN;
        }
        if (value > TEXT_ZOOM_MAX) {
            value = TEXT_ZOOM_MAX;
        }
        prefs.edit().putInt(zoomKey(t), value).apply();
        t.web.getSettings().setTextZoom(value);
        Toast.makeText(this, "גודל טקסט באתר הזה: " + value + "%", Toast.LENGTH_SHORT).show();
    }

    private void toggleWebDark() {
        webDark = !webDark;
        prefs.edit().putBoolean("web_dark", webDark).apply();
        for (Tab t : tabs) {
            if (t.web != null) {
                applyDark(t.web);
            }
        }
        WebView w = currentWeb();
        if (w != null) {
            w.reload();
        }
        Toast.makeText(this, webDark ? "הכהיית אתרים הופעלה" : "הכהיית אתרים כובתה",
                Toast.LENGTH_SHORT).show();
    }

    @SuppressWarnings("deprecation")
    private void applyDark(WebView wv) {
        WebSettings s = wv.getSettings();
        if (Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(webDark);
        } else if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(webDark ? WebSettings.FORCE_DARK_AUTO : WebSettings.FORCE_DARK_OFF);
        }
    }

    private void confirmClearData() {
        new AlertDialog.Builder(this)
                .setTitle("ניקוי נתונים")
                .setMessage("הפעולה תנתק אותך מכל האתרים ותמחק עוגיות ומטמון. להמשיך?")
                .setPositiveButton("נקה", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        clearAllData();
                    }
                })
                .setNegativeButton("ביטול", null)
                .show();
    }

    private void clearAllData() {
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        for (Tab t : tabs) {
            if (t.web != null) {
                t.web.clearCache(true);
                t.web.clearHistory();
            }
        }
        Tab cur = currentTab();
        if (cur != null && cur.web != null) {
            cur.web.loadUrl(cur.url);
        }
        Toast.makeText(this, "הנתונים נמחקו", Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- lock & privacy

    private void applySecure() {
        if (secure) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
    }

    private void toggleSecure() {
        secure = !secure;
        prefs.edit().putBoolean("secure", secure).apply();
        applySecure();
        Toast.makeText(this, secure ? "צילומי מסך נחסמו" : "צילומי מסך מותרים",
                Toast.LENGTH_SHORT).show();
    }

    private boolean deviceHasSecureLock() {
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    private void toggleLock() {
        if (!lockEnabled) {
            if (!deviceHasSecureLock()) {
                Toast.makeText(this, "כדי להפעיל נעילה, צריך להגדיר נעילת מסך בטלפון",
                        Toast.LENGTH_LONG).show();
                return;
            }
            lockEnabled = true;
            prefs.edit().putBoolean("lock_enabled", true).apply();
            Toast.makeText(this, "הנעילה הופעלה", Toast.LENGTH_SHORT).show();
        } else {
            lockEnabled = false;
            prefs.edit().putBoolean("lock_enabled", false).apply();
            setLocked(false);
            Toast.makeText(this, "הנעילה כובתה", Toast.LENGTH_SHORT).show();
        }
    }

    private void setLocked(boolean value) {
        locked = value;
        if (lockView != null) {
            lockView.setVisibility(value ? View.VISIBLE : View.GONE);
        }
        if (value) {
            authDeclined = false;
        }
    }

    private void disableLockUnavailable() {
        lockEnabled = false;
        prefs.edit().putBoolean("lock_enabled", false).apply();
        setLocked(false);
        Toast.makeText(this, "לא מוגדרת נעילת מסך בטלפון, ולכן הנעילה כובתה",
                Toast.LENGTH_LONG).show();
    }

    private void startAuth() {
        if (authInProgress) {
            return;
        }
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (km == null || !km.isDeviceSecure()) {
            disableLockUnavailable();
            return;
        }
        Intent i = km.createConfirmDeviceCredentialIntent(
                "צ׳אטים", "אמת את זהותך כדי לפתוח את האפליקציה");
        if (i == null) {
            disableLockUnavailable();
            return;
        }
        try {
            authInProgress = true;
            startActivityForResult(i, AUTH_REQ);
        } catch (ActivityNotFoundException e) {
            authInProgress = false;
            disableLockUnavailable();
        }
    }

    // ---------------------------------------------------------------- web

    private WebView createWebView(final Tab t) {
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setTextZoom(prefs.getInt(zoomKey(t), 100));
        applyDark(wv);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimetype);
            }
        });

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false; // נשאר בתוך האפליקציה
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "אין אפליקציה שיכולה לפתוח את הקישור",
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                t.hadError = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!t.hadError && t.errorView != null) {
                    t.errorView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    t.hadError = true;
                    if (t.errorView != null) {
                        t.errorView.setVisibility(View.VISIBLE);
                    }
                }
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (view == currentWeb()) {
                    progress.setProgress(newProgress);
                    progress.setVisibility(newProgress < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                handlePermissionRequest(request);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        return wv;
    }

    // מצלמה ומיקרופון לאתרים

    private String permissionFor(String resource) {
        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
            return Manifest.permission.CAMERA;
        }
        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
            return Manifest.permission.RECORD_AUDIO;
        }
        return null;
    }

    private String[] grantableResources(String[] resources) {
        List<String> ok = new ArrayList<String>();
        for (String r : resources) {
            String perm = permissionFor(r);
            if (perm != null
                    && checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        return ok.toArray(new String[0]);
    }

    private void handlePermissionRequest(PermissionRequest request) {
        String[] resources = request.getResources();
        List<String> missing = new ArrayList<String>();
        boolean supported = false;
        for (String r : resources) {
            String perm = permissionFor(r);
            if (perm == null) {
                continue;
            }
            supported = true;
            if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED
                    && !missing.contains(perm)) {
                missing.add(perm);
            }
        }
        if (!supported) {
            request.deny();
            return;
        }
        if (missing.isEmpty()) {
            request.grant(grantableResources(resources));
            return;
        }
        if (pendingPermission != null) {
            pendingPermission.deny();
        }
        pendingPermission = request;
        requestPermissions(missing.toArray(new String[0]), PERM_REQ);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERM_REQ && pendingPermission != null) {
            String[] ok = grantableResources(pendingPermission.getResources());
            if (ok.length > 0) {
                pendingPermission.grant(ok);
            } else {
                pendingPermission.deny();
            }
            pendingPermission = null;
        }
    }

    private void startDownload(String url, String userAgent, String contentDisposition,
                               String mimetype) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            Toast.makeText(this, "סוג ההורדה הזה אינו נתמך", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) {
                r.addRequestHeader("Cookie", cookies);
            }
            if (userAgent != null) {
                r.addRequestHeader("User-Agent", userAgent);
            }
            if (mimetype != null) {
                r.setMimeType(mimetype);
            }
            r.setTitle(name);
            r.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, "מוריד: " + name, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openUrl(url);
        }
    }

    // ---------------------------------------------------------------- external

    private void openGoogleChatApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(GOOGLE_CHAT_PACKAGE);
        if (launch != null) {
            startActivity(launch);
            return;
        }
        Toast.makeText(this, "Google Chat לא מותקנת. פותח את החנות", Toast.LENGTH_SHORT).show();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + GOOGLE_CHAT_PACKAGE)));
        } catch (ActivityNotFoundException e) {
            openUrl("https://play.google.com/store/apps/details?id=" + GOOGLE_CHAT_PACKAGE);
        }
    }

    /**
     * פותח כתובת בדפדפן בלבד. הבחירה בקטגוריית "דפדפן" מונעת מאנדרואיד להעביר
     * את הקישור לאפליקציה שרשומה לטפל בו.
     */
    private void openUrl(String url) {
        Uri uri = Uri.parse(url);
        try {
            Intent browser = Intent.makeMainSelectorActivity(
                    Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
            browser.setData(uri);
            startActivity(browser);
            return;
        } catch (ActivityNotFoundException e) {
            // ממשיכים לפתיחה רגילה
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "לא נמצא דפדפן", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        if (requestCode == AUTH_REQ) {
            authInProgress = false;
            if (resultCode == RESULT_OK) {
                setLocked(false);
            } else {
                authDeclined = true;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (locked) {
            super.onBackPressed();
            return;
        }
        if (manageView.getVisibility() == View.VISIBLE) {
            manageView.setVisibility(View.GONE);
            return;
        }
        if (guideView.getVisibility() == View.VISIBLE) {
            guideView.setVisibility(View.GONE);
            return;
        }
        WebView w = currentWeb();
        if (w != null && w.canGoBack()) {
            w.goBack();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackTime < 2000) {
            super.onBackPressed();
        } else {
            lastBackTime = now;
            Toast.makeText(this, "לחץ שוב כדי לצאת", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (lockEnabled && !locked && !authInProgress && backgroundTime > 0
                && SystemClock.elapsedRealtime() - backgroundTime > LOCK_DELAY_MS) {
            setLocked(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lockEnabled && locked && !authInProgress && !authDeclined) {
            startAuth();
        }
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onStop() {
        backgroundTime = SystemClock.elapsedRealtime();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            destroyTab(t);
        }
        super.onDestroy();
    }
}

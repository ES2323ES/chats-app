package com.example.chats;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * אפליקציית צאטים עם לשוניות.
 * לשונית רגילה = WebView שנשמר בזיכרון (המצב לא אובד במעבר בין לשוניות).
 * לשונית Google Chat = מסך שמפעיל את האפליקציה הרשמית של Google או את הדפדפן,
 * כי Google לא מאפשרת התחברות בתוך WebView של אפליקציות צד שלישי.
 *
 * להוספת אתר: הוסף שורה ב-TITLES, ב-URLS וב-NATIVE_PANEL (באותו סדר).
 */
public class MainActivity extends Activity {

    private static final String GOOGLE_CHAT_PACKAGE = "com.google.android.apps.dynamite";
    private static final String GOOGLE_CHAT_URL = "https://chat.google.com/";

    private static final String[] TITLES = {"חתול שחור", "עליאקספרס", "גוגל צ'אט"};
    private static final String[] URLS = {
            "https://black-cat.thechats.click/",
            "https://aliexpress.thechats.click/",
            GOOGLE_CHAT_URL
    };
    // true = מסך הפעלה של Google Chat במקום WebView
    private static final boolean[] NATIVE_PANEL = {false, false, true};

    private static final int FILE_REQ = 1001;

    private final View[] views = new View[TITLES.length];
    private final Button[] tabButtons = new Button[TITLES.length];
    private FrameLayout content;
    private int current = -1;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor("#EEEEEE"));
        bar.setGravity(Gravity.CENTER_VERTICAL);

        for (int i = 0; i < TITLES.length; i++) {
            final int index = i;
            Button b = new Button(this);
            b.setText(TITLES[i]);
            b.setAllCaps(false);
            b.setSingleLine(true);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    select(index);
                }
            });
            bar.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabButtons[i] = b;
        }

        Button external = new Button(this);
        external.setText("↗");
        external.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openExternal();
            }
        });
        bar.addView(external, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content = new FrameLayout(this);

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        select(0);
    }

    private void select(int index) {
        if (views[index] == null) {
            views[index] = NATIVE_PANEL[index] ? createGoogleChatPanel() : createWebView(index);
            content.addView(views[index], new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        for (int i = 0; i < views.length; i++) {
            if (views[i] != null) {
                views[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            }
            tabButtons[i].setBackgroundColor(i == index
                    ? Color.parseColor("#BBDEFB") : Color.TRANSPARENT);
        }
        current = index;
    }

    private View createGoogleChatPanel() {
        int pad = (int) (24 * getResources().getDisplayMetrics().density);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("גוגל צ'אט");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("Google אינה מאפשרת התחברות בתוך אפליקציות כמו זו, מטעמי אבטחה. "
                + "לכן הצ'אט נפתח באפליקציה הרשמית של Google Chat, או בדפדפן.");
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, pad, 0, pad);

        Button openApp = new Button(this);
        openApp.setText("פתח באפליקציית Google Chat");
        openApp.setAllCaps(false);
        openApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGoogleChatApp();
            }
        });

        Button openWeb = new Button(this);
        openWeb.setText("פתח בדפדפן");
        openWeb.setAllCaps(false);
        openWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUrl(GOOGLE_CHAT_URL);
            }
        });

        panel.addView(title);
        panel.addView(info);
        panel.addView(openApp);
        panel.addView(openWeb);
        return panel;
    }

    private void openGoogleChatApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(GOOGLE_CHAT_PACKAGE);
        if (launch != null) {
            startActivity(launch);
            return;
        }
        Toast.makeText(this, "Google Chat לא מותקנת. פותח את החנות", Toast.LENGTH_SHORT).show();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + GOOGLE_CHAT_PACKAGE)));
        } catch (ActivityNotFoundException e) {
            openUrl("https://play.google.com/store/apps/details?id=" + GOOGLE_CHAT_PACKAGE);
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "לא נמצא דפדפן", Toast.LENGTH_SHORT).show();
        }
    }

    private WebView createWebView(int index) {
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false; // נשאר בתוך האפליקציה
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "אין אפליקציה שיכולה לפתוח את הקישור",
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        wv.loadUrl(URLS[index]);
        return wv;
    }

    /** פותח את הלשונית הנוכחית בדפדפן. */
    private void openExternal() {
        if (current < 0) return;
        String url = URLS[current];
        View v = views[current];
        if (v instanceof WebView && ((WebView) v).getUrl() != null) {
            url = ((WebView) v).getUrl();
        }
        openUrl(url);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (current >= 0 && views[current] instanceof WebView) {
            WebView wv = (WebView) views[current];
            if (wv.canGoBack()) {
                wv.goBack();
                return;
            }
        }
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        for (View v : views) {
            if (v instanceof WebView) {
                content.removeView(v);
                ((WebView) v).destroy();
            }
        }
        super.onDestroy();
    }
}

package com.example.chats;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * צ׳אטים: אפליקציה עם לשוניות.
 * לשונית רגילה = WebView שנשמר בזיכרון, עם מסך שגיאה בעברית.
 * לשונית Google Chat = מסך שמפעיל את האפליקציה הרשמית של Google,
 * כי Google לא מאפשרת התחברות בתוך WebView של אפליקציות צד שלישי.
 *
 * להוספת אתר: הוסף שורה ב-TITLES, ב-URLS וב-NATIVE_PANEL (באותו סדר).
 */
public class MainActivity extends Activity {

    private static final String GOOGLE_CHAT_PACKAGE = "com.google.android.apps.dynamite";
    private static final String GOOGLE_CHAT_URL = "https://chat.google.com/";

    private static final String[] TITLES = {"החתול השחור", "עלי אקספרס", "גוגל צ'אט"};
    private static final String[] URLS = {
            "https://black-cat.thechats.click/",
            "https://aliexpress.thechats.click/",
            GOOGLE_CHAT_URL
    };
    // true = מסך הפעלה של Google Chat במקום WebView
    private static final boolean[] NATIVE_PANEL = {false, false, true};

    private static final int FILE_REQ = 1001;
    private static final int TEXT_ZOOM_MIN = 70;
    private static final int TEXT_ZOOM_MAX = 200;

    private static final String GUIDE_TEXT =
            "הלשוניות\n"
            + "בראש המסך יש לשוניות: החתול השחור, עלי אקספרס וגוגל צ'אט. לחיצה על לשונית עוברת אליה, "
            + "והאתר נשמר במצבו כשחוזרים אליו. האפליקציה נפתחת בלשונית שבה סגרת אותה.\n\n"
            + "כפתור ↻\n"
            + "מרענן את הדף הנוכחי. פס דק מתחת לשורה מראה את התקדמות הטעינה.\n\n"
            + "תפריט ⋮\n"
            + "• רענן: טוען מחדש את הדף.\n"
            + "• שתף קישור / העתק קישור: של הדף הנוכחי.\n"
            + "• פתח בדפדפן: פותח את הדף הנוכחי בכרום או בדפדפן אחר.\n"
            + "• הגדל / הקטן / אפס גודל טקסט: משנה את גודל הכתב באתרים.\n"
            + "• הכהיית אתרים: מכהה אתרים אוטומטית כשהטלפון במצב כהה. אם אתר נראה רע, אפשר לכבות.\n"
            + "• התנתק ונקה נתונים: מוחק עוגיות ומטמון של כל האתרים, ותצטרך להתחבר מחדש. "
            + "שימושי כשהתחברות נתקעת.\n\n"
            + "גוגל צ'אט\n"
            + "Google אינה מאפשרת התחברות בתוך אפליקציות כמו זו, ולכן הלשונית פותחת את אפליקציית "
            + "Google Chat הרשמית. אם היא לא מותקנת, תיפתח החנות.\n\n"
            + "הורדת קבצים\n"
            + "קבצים שהאתר מציע להורדה נשמרים בתיקיית ההורדות של הטלפון. "
            + "הורדות מסוימות שנוצרות בתוך הדף עצמו אינן נתמכות.\n\n"
            + "שגיאות\n"
            + "אם אין חיבור או שהאתר לא זמין, יוצג מסך עם כפתור נסה שוב.\n\n"
            + "יציאה\n"
            + "לחיצה על חזור חוזרת אחורה בדף. כשאי אפשר לחזור, צריך ללחוץ פעמיים כדי לצאת מהאפליקציה.";

    private final FrameLayout[] holders = new FrameLayout[TITLES.length];
    private final WebView[] webs = new WebView[TITLES.length];
    private final View[] errorViews = new View[TITLES.length];
    private final boolean[] hadError = new boolean[TITLES.length];
    private final Button[] tabButtons = new Button[TITLES.length];

    private FrameLayout content;
    private ProgressBar progress;
    private View guideView;
    private SharedPreferences prefs;
    private boolean night;
    private boolean webDark;
    private int textZoom;
    private int current = -1;
    private long lastBackTime = 0;
    private ValueCallback<Uri[]> filePathCallback;

    // ---------------------------------------------------------------- UI

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("chats", MODE_PRIVATE);
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        textZoom = prefs.getInt("text_zoom", 100);
        webDark = prefs.getBoolean("web_dark", true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.parseColor(night ? "#2B2B2B" : "#EEEEEE"));
        bar.setGravity(Gravity.CENTER_VERTICAL);

        for (int i = 0; i < TITLES.length; i++) {
            final int index = i;
            Button b = newBarButton(TITLES[i]);
            b.setSingleLine(true);
            b.setTextSize(13);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    select(index);
                }
            });
            bar.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabButtons[i] = b;
        }

        Button refresh = newBarButton("↻");
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshCurrent();
            }
        });
        bar.addView(refresh, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button menu = newBarButton("⋮");
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu(v);
            }
        });
        bar.addView(menu, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.INVISIBLE);

        content = new FrameLayout(this);
        guideView = createGuideView();
        content.addView(guideView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(progress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        int last = prefs.getInt("last_tab", 0);
        if (last < 0 || last >= TITLES.length) {
            last = 0;
        }
        select(last);
    }

    private Button newBarButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private int surfaceColor() {
        return night ? Color.parseColor("#121212") : Color.WHITE;
    }

    private void select(int index) {
        if (holders[index] == null) {
            createTab(index);
        }
        for (int i = 0; i < holders.length; i++) {
            if (holders[i] != null) {
                holders[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            }
            tabButtons[i].setBackgroundColor(i == index
                    ? Color.parseColor(night ? "#37474F" : "#BBDEFB")
                    : Color.TRANSPARENT);
        }
        current = index;
        prefs.edit().putInt("last_tab", index).apply();
        updateProgress();
    }

    private void createTab(int index) {
        FrameLayout holder = new FrameLayout(this);
        FrameLayout.LayoutParams match = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        if (NATIVE_PANEL[index]) {
            holder.addView(createGoogleChatPanel(), match);
        } else {
            WebView wv = createWebView(index);
            webs[index] = wv;
            holder.addView(wv, match);

            View err = createErrorView(index);
            err.setVisibility(View.GONE);
            errorViews[index] = err;
            holder.addView(err, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            wv.loadUrl(URLS[index]);
        }
        holders[index] = holder;
        content.addView(holder, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void updateProgress() {
        WebView w = (current >= 0) ? webs[current] : null;
        if (w != null && w.getProgress() < 100) {
            progress.setProgress(w.getProgress());
            progress.setVisibility(View.VISIBLE);
        } else {
            progress.setVisibility(View.INVISIBLE);
        }
    }

    private View createGoogleChatPanel() {
        int pad = dp(24);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("גוגל צ'אט");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("Google אינה מאפשרת התחברות בתוך אפליקציות כמו זו, מטעמי אבטחה. "
                + "לכן הצ'אט נפתח באפליקציה הרשמית של Google Chat.");
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, pad, 0, pad);

        Button openApp = new Button(this);
        openApp.setText("פתח באפליקציית Google Chat");
        openApp.setAllCaps(false);
        openApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGoogleChatApp();
            }
        });

        panel.addView(title);
        panel.addView(info);
        panel.addView(openApp);
        return panel;
    }

    private View createErrorView(final int index) {
        int pad = dp(24);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(pad, pad, pad, pad);
        box.setBackgroundColor(surfaceColor());
        box.setClickable(true); // חוסם לחיצות על ה-WebView שמתחת

        TextView msg = new TextView(this);
        msg.setText("אין חיבור לאינטרנט, או שהאתר לא זמין כרגע.");
        msg.setTextSize(18);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 0, 0, pad);

        Button retry = new Button(this);
        retry.setText("נסה שוב");
        retry.setAllCaps(false);
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (webs[index] != null) {
                    webs[index].loadUrl(URLS[index]);
                }
            }
        });

        box.addView(msg);
        box.addView(retry);
        return box;
    }

    private View createGuideView() {
        int pad = dp(20);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(surfaceColor());
        scroll.setClickable(true);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("מדריך למשתמש");
        title.setTextSize(22);
        title.setPadding(0, 0, 0, pad);

        TextView body = new TextView(this);
        body.setText(GUIDE_TEXT);
        body.setTextSize(16);
        body.setLineSpacing(0f, 1.2f);

        Button close = new Button(this);
        close.setText("סגור");
        close.setAllCaps(false);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guideView.setVisibility(View.GONE);
            }
        });

        box.addView(title);
        box.addView(body);
        box.addView(close);
        scroll.addView(box);
        scroll.setVisibility(View.GONE);
        return scroll;
    }

    private void showGuide() {
        guideView.setVisibility(View.VISIBLE);
        guideView.bringToFront();
    }

    // ---------------------------------------------------------------- menu

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        boolean web = current >= 0 && webs[current] != null;
        if (web) {
            m.add(0, 1, 0, "רענן");
            m.add(0, 2, 0, "שתף קישור");
            m.add(0, 3, 0, "העתק קישור");
            m.add(0, 4, 0, "פתח בדפדפן");
            m.add(0, 5, 0, "הגדל טקסט");
            m.add(0, 6, 0, "הקטן טקסט");
            m.add(0, 7, 0, "אפס גודל טקסט");
        }
        m.add(0, 8, 0, webDark ? "כבה הכהיית אתרים" : "הפעל הכהיית אתרים");
        m.add(0, 9, 0, "התנתק ונקה נתונים");
        m.add(0, 10, 0, "מדריך");

        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case 1:
                        refreshCurrent();
                        break;
                    case 2:
                        shareCurrentUrl();
                        break;
                    case 3:
                        copyCurrentUrl();
                        break;
                    case 4:
                        openUrl(currentUrl());
                        break;
                    case 5:
                        setTextZoom(textZoom + 10);
                        break;
                    case 6:
                        setTextZoom(textZoom - 10);
                        break;
                    case 7:
                        setTextZoom(100);
                        break;
                    case 8:
                        toggleWebDark();
                        break;
                    case 9:
                        confirmClearData();
                        break;
                    case 10:
                        showGuide();
                        break;
                    default:
                        break;
                }
                return true;
            }
        });
        pm.show();
    }

    private String currentUrl() {
        if (current < 0) {
            return URLS[0];
        }
        WebView w = webs[current];
        if (w != null && w.getUrl() != null) {
            return w.getUrl();
        }
        return URLS[current];
    }

    private void refreshCurrent() {
        if (current >= 0 && webs[current] != null) {
            webs[current].reload();
        } else {
            Toast.makeText(this, "אין מה לרענן בלשונית הזו", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareCurrentUrl() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, currentUrl());
        startActivity(Intent.createChooser(send, "שתף קישור"));
    }

    private void copyCurrentUrl() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("link", currentUrl()));
            Toast.makeText(this, "הקישור הועתק", Toast.LENGTH_SHORT).show();
        }
    }

    private void setTextZoom(int value) {
        if (value < TEXT_ZOOM_MIN) {
            value = TEXT_ZOOM_MIN;
        }
        if (value > TEXT_ZOOM_MAX) {
            value = TEXT_ZOOM_MAX;
        }
        textZoom = value;
        prefs.edit().putInt("text_zoom", textZoom).apply();
        for (WebView w : webs) {
            if (w != null) {
                w.getSettings().setTextZoom(textZoom);
            }
        }
        Toast.makeText(this, "גודל טקסט: " + textZoom + "%", Toast.LENGTH_SHORT).show();
    }

    private void toggleWebDark() {
        webDark = !webDark;
        prefs.edit().putBoolean("web_dark", webDark).apply();
        for (WebView w : webs) {
            if (w != null) {
                applyDark(w);
            }
        }
        if (current >= 0 && webs[current] != null) {
            webs[current].reload();
        }
        Toast.makeText(this, webDark ? "הכהיית אתרים הופעלה" : "הכהיית אתרים כובתה",
                Toast.LENGTH_SHORT).show();
    }

    @SuppressWarnings("deprecation")
    private void applyDark(WebView wv) {
        WebSettings s = wv.getSettings();
        if (Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(webDark);
        } else if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(webDark ? WebSettings.FORCE_DARK_AUTO : WebSettings.FORCE_DARK_OFF);
        }
    }

    private void confirmClearData() {
        new AlertDialog.Builder(this)
                .setTitle("ניקוי נתונים")
                .setMessage("הפעולה תנתק אותך מכל האתרים ותמחק עוגיות ומטמון. להמשיך?")
                .setPositiveButton("נקה", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        clearAllData();
                    }
                })
                .setNegativeButton("ביטול", null)
                .show();
    }

    private void clearAllData() {
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        for (int i = 0; i < webs.length; i++) {
            if (webs[i] != null) {
                webs[i].clearCache(true);
                webs[i].clearHistory();
            }
        }
        if (current >= 0 && webs[current] != null) {
            webs[current].loadUrl(URLS[current]);
        }
        Toast.makeText(this, "הנתונים נמחקו", Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- web

    private WebView createWebView(final int index) {
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setTextZoom(textZoom);
        applyDark(wv);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(wv, true);

        wv.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                startDownload(url, userAgent, contentDisposition, mimetype);
            }
        });

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return false; // נשאר בתוך האפליקציה
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "אין אפליקציה שיכולה לפתוח את הקישור",
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                hadError[index] = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!hadError[index] && errorViews[index] != null) {
                    errorViews[index].setVisibility(View.GONE);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    hadError[index] = true;
                    if (errorViews[index] != null) {
                        errorViews[index].setVisibility(View.VISIBLE);
                    }
                }
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (current >= 0 && view == webs[current]) {
                    progress.setProgress(newProgress);
                    progress.setVisibility(newProgress < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        return wv;
    }

    private void startDownload(String url, String userAgent, String contentDisposition,
                               String mimetype) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            Toast.makeText(this, "סוג ההורדה הזה אינו נתמך", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mimetype);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) {
                r.addRequestHeader("Cookie", cookies);
            }
            if (userAgent != null) {
                r.addRequestHeader("User-Agent", userAgent);
            }
            if (mimetype != null) {
                r.setMimeType(mimetype);
            }
            r.setTitle(name);
            r.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, "מוריד: " + name, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openUrl(url);
        }
    }

    // ---------------------------------------------------------------- external

    private void openGoogleChatApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(GOOGLE_CHAT_PACKAGE);
        if (launch != null) {
            startActivity(launch);
            return;
        }
        Toast.makeText(this, "Google Chat לא מותקנת. פותח את החנות", Toast.LENGTH_SHORT).show();
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + GOOGLE_CHAT_PACKAGE)));
        } catch (ActivityNotFoundException e) {
            openUrl("https://play.google.com/store/apps/details?id=" + GOOGLE_CHAT_PACKAGE);
        }
    }

    /**
     * פותח כתובת בדפדפן בלבד. הבחירה בקטגוריית "דפדפן" מונעת מאנדרואיד להעביר
     * את הקישור לאפליקציה שרשומה לטפל בו.
     */
    private void openUrl(String url) {
        Uri uri = Uri.parse(url);
        try {
            Intent browser = Intent.makeMainSelectorActivity(
                    Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
            browser.setData(uri);
            startActivity(browser);
            return;
        } catch (ActivityNotFoundException e) {
            // ממשיכים לפתיחה רגילה
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "לא נמצא דפדפן", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (guideView.getVisibility() == View.VISIBLE) {
            guideView.setVisibility(View.GONE);
            return;
        }
        if (current >= 0 && webs[current] != null && webs[current].canGoBack()) {
            webs[current].goBack();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackTime < 2000) {
            super.onBackPressed();
        } else {
            lastBackTime = now;
            Toast.makeText(this, "לחץ שוב כדי לצאת", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        for (int i = 0; i < webs.length; i++) {
            if (webs[i] != null) {
                if (holders[i] != null) {
                    holders[i].removeView(webs[i]);
                }
                webs[i].destroy();
                webs[i] = null;
            }
        }
        super.onDestroy();
    }
}
